﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthServer.Data.Models;
using AuthServer.Data.Persistance;
using AuthServer.CustomException;

namespace AuthServer.Services
{
    public class UserService : IUserService
    {
        public readonly IUserRepository _repo;

        public UserService(IUserRepository repo)
        {
            _repo = repo;
        }
        public bool IsUserExists(string userId)
        {
            var user = _repo.FindUserById(userId);
            if (user != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public User Login(string userId, string password)
        {
            var user = _repo.Login(userId, password);
            if(user!=null)
            {
                return user;
            }
            else
            {
               throw new UserNotFoundException("Record not found error");
            }
        }

        public User Register(User user)
        {
            var _user = _repo.Register(user);
            return _user;
        }
    }
}
