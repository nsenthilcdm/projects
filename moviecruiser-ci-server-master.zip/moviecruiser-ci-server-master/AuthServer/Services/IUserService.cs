﻿using AuthServer.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthServer.Services
{
    public interface IUserService
    {
        User Register(User user);
        User Login(string userId, string password);
        bool IsUserExists(string userId);
    }
}
