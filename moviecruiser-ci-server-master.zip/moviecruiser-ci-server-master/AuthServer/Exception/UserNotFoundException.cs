﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthServer.CustomException
{
    [Serializable]
    public class UserNotFoundException : System.Exception
    {
        public UserNotFoundException()
        {

        }

        public UserNotFoundException(string message)
            : base(message)
        {

        }

    }
}
