﻿using AuthServer.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthServer.Data.Persistance
{
    public class UserRepository : IUserRepository
    {
        private readonly IUsersDBContext _context;

        /// <summary>
        /// Contructor to initiliaze DB context
        /// </summary>
        /// <param name="context">holds Db context.</param>
        public UserRepository(IUsersDBContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Method to find the user by userid
        /// </summary>
        /// <param name="userId">Holds userid</param>
        /// <returns></returns>
        public User FindUserById(string userId)
        {
            User _user = _context.Users.FirstOrDefault(u => u.UserId == userId);
            return _user;
        }
        /// <summary>
        /// Method to verify the user id and pasword.
        /// </summary>
        /// <param name="userId">holds user id</param>
        /// <param name="password">holds password</param>
        /// <returns></returns>
        public User Login(string userId, string password)
        {
            User _user = _context.Users.FirstOrDefault(u => u.UserId == userId && u.Password == password);
            return _user;
        }
        /// <summary>
        /// Method to register the user
        /// </summary>
        /// <param name="user">holds the user object</param>
        /// <returns>returns user</returns>
        public User Register(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return user;
        }
    }
}
