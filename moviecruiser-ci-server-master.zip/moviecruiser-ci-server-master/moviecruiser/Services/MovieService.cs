﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using moviecruiser.Data.Models;
using moviecruiser.Data.Persistance;
using System.Collections.Generic;

namespace moviecruiser.Services
{
    /// <summary>
    /// Service class contains rapper methods for repository.
    /// </summary>
    public class MovieService : IMovieService
    {
        private readonly IMovieRepository _repo;
        private StringValues userId = new StringValues();
        public MovieService(IMovieRepository repo,IHttpContextAccessor contextAccessor)
        {
            _repo = repo;
            var context = contextAccessor;
            context.HttpContext.Request.Headers.TryGetValue("userId",out userId);
        }
        /// <summary>
        /// Method to create movie.
        /// </summary>
        /// <param name="movie">holds movie object</param>
        /// <returns>return success result</returns>
        public bool CreateMovie(Movie movie)
        {
            movie.UserId = this.userId;
            return _repo.Create(movie);
        }
        /// <summary>
        /// Method to get all movies.
        /// </summary>
        /// <returns>returns movie list.</returns>
        public List<Movie> GetAllMovies()
        {
            return _repo.GetAllMovies(this.userId);
        }
        /// <summary>
        /// Method to get movie by movie id
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <returns>returns movie detail</returns>
        public Movie GetMovieById(int id)
        {
            return _repo.GetMovieById(id, this.userId);
        }
        /// <summary>
        /// Method to delete movie.
        /// </summary>
        /// <param name="id">holds movie id</param>
        /// <returns>return result</returns>
        public bool RemoveMovie(int id)
        {
            return _repo.Remove(id, this.userId);
        }
        /// <summary>
        /// Method to update movie comment.
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <param name="comment">holds comment.</param>
        /// <returns>return update movie details</returns>
        public Movie UpdateMovie(int id, string comment)
        {
            return _repo.Update(id, this.userId,comment);
        }
    }
}
