﻿using moviecruiser.Data.Models;
using System.Collections.Generic;

namespace moviecruiser.Services
{
    /// <summary>
    /// Service interface contains rapper methods for repository.
    /// </summary>
    public interface IMovieService
    {
        /// <summary>
        /// Method to get all movies.
        /// </summary>
        /// <returns>returns movie list.</returns>
        List<Movie> GetAllMovies();
        /// <summary>
        /// Method to get movie by movie id
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <returns>returns movie detail</returns>
        Movie GetMovieById(int id);
        /// <summary>
        /// Method to create movie.
        /// </summary>
        /// <param name="movie">holds movie object</param>
        /// <returns>return success result</returns>
        bool CreateMovie(Movie movie);
        /// <summary>
        /// Method to update movie comment.
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <param name="comment">holds comment.</param>
        /// <returns>return update movie details</returns>
        Movie UpdateMovie(int id,string comment);
        /// <summary>
        /// Method to delete movie.
        /// </summary>
        /// <param name="id">holds movie id</param>
        /// <returns>return result</returns>
        bool RemoveMovie(int id);
    }
}
