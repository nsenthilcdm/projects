﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using moviecruiser.Data.Models;
using moviecruiser.Services;
using System;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace moviecruiser.Controllers
{
    /// <summary>
    /// Controller contains method for managing movies.
    /// </summary>
    [Authorize]
    [Route("api/[controller]")]
    public class MovieController : Controller
    {
        private readonly IMovieService _service;
        /// <summary>
        /// Constructor to initialize the movie service.
        /// </summary>
        /// <param name="service"></param>
        public MovieController(IMovieService service)
        {
            _service = service;
        }
        // GET: api/<controller>
        /// <summary>
        /// Get method to get all the movie details.
        /// </summary>
        /// <returns>return movies list</returns>
        [HttpGet]
        public ActionResult Get()
        {
            try
            {
                List<Movie> movies = _service.GetAllMovies();
                return Ok(movies);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {         
                return StatusCode(500);
            }
        }

        // GET api/<controller>/5
        /// <summary>
        /// Method to get Movie by movie id.
        /// </summary>
        /// <param name="id">holds movie id</param>
        /// <returns>returns teh movie record.</returns>
        [HttpGet("{id}")]
        public ActionResult Get(int id)
        {
            try
            {
                Movie movie = _service.GetMovieById(id);
                if (movie == null)
                {
                    return NotFound("Record not found");
                }
                else
                {
                    return Ok(movie);
                }
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        // POST api/<controller>
        /// <summary>
        /// Post method to create a movie.
        /// </summary>
        /// <param name="value">holds the movie details.</param>
        /// <returns>returns success message</returns>
        [HttpPost]
        public ActionResult Post([FromBody]Movie value)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(value);
                Movie movie = _service.GetMovieById(value.Id);
                if (movie == null)
                {
                    bool result = _service.CreateMovie(value);
                    return CreatedAtAction("Post", result);
                }
                else
                {                   
                    return StatusCode(409);
                }
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        // PUT api/<controller>/5
        /// <summary>
        /// Put method to update teh movie comments.
        /// </summary>
        /// <param name="id">Holds movie id</param>
        /// <param name="comment">Holds movie comments</param>
        /// <returns>returns the updated movie recors.</returns>
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody]string comment)
        {
            try
            {
                return Ok(_service.UpdateMovie(id,comment));
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        // DELETE api/<controller>/5
        /// <summary>
        /// Method to delete the movie.
        /// </summary>
        /// <param name="id">holds the movie id to be deleted.</param>
        /// <returns>returns ok message.</returns>
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            try
            {
                if (_service.RemoveMovie(id))
                {
                    return Ok(true);
                }
                else
                {
                    return NotFound("Record not found");
                }
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }
    }
}
