﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace moviecruiser.Data.Models
{
    public class Movie
    {
        /// <summary>
        /// Sets or gets movie id
        /// </summary>
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(Order=1)]
        [JsonProperty(PropertyName ="id")]
        public int Id { get; set; }
        /// <summary>
        /// Sets or gets User id
        /// </summary>
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(Order = 2)]
        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }
        /// <summary>
        /// Gets or sets movie name.
        /// </summary>
        [JsonProperty(PropertyName = "title")]
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets comments.
        /// </summary>
        [JsonProperty(PropertyName = "comments")]
        public string Comments { get; set; }
        /// <summary>
        /// Gets or sets poster path.
        /// </summary>
        [JsonProperty(PropertyName = "poster_path")]
        public string PosterPath { get; set; }
        /// <summary>
        /// Gets or sets release date.
        /// </summary>
        [JsonProperty(PropertyName = "release_date")]
        public string ReleaseDate { get; set; }
        /// <summary>
        /// Gets or sets vote average
        /// </summary>
        [JsonProperty(PropertyName = "vote_average")]
        public double VoteAverage { get; set; }
        /// <summary>
        /// Gets or sets vote count.
        /// </summary>
        [JsonProperty(PropertyName = "vote_count")]        
        public int VoteCount { get; set; }
        /// <summary>
        /// Gets or sets overview.
        /// </summary>
        [JsonProperty(PropertyName = "overview")]
        public string Overview { get; set; }
    }
}
