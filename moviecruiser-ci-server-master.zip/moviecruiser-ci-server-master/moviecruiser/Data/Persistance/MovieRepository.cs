﻿using moviecruiser.Data.Models;
using System.Collections.Generic;
using System.Linq;

namespace moviecruiser.Data.Persistance
{
    /// <summary>
    /// Class contains method to manage movies.
    /// </summary>
    public class MovieRepository : IMovieRepository
    {
        private readonly IMoviesDBContext _context;

        /// <summary>
        /// Contructor to initiliaze DB context
        /// </summary>
        /// <param name="context">holds Db context.</param>
        public MovieRepository(IMoviesDBContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Method to get all movies.
        /// </summary>
        /// <returns>returns movie list.</returns>
        public List<Movie> GetAllMovies(string userId)
        {
            return _context.Movies.Where(x=>x.UserId.Equals(userId, System.StringComparison.InvariantCultureIgnoreCase)).Select(x => x).ToList();
        }
        /// <summary>
        /// Method to get movie by movie id
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <returns>returns movie detail</returns>
        public Movie GetMovieById(int id,string userId)
        {
            return _context.Movies.Where(x => x.Id == id && x.UserId.Equals(userId, System.StringComparison.InvariantCultureIgnoreCase)).Select(x => x).FirstOrDefault();
        }
        /// <summary>
        /// Method to create movie.
        /// </summary>
        /// <param name="movie">holds movie object</param>
        /// <returns>return success result</returns>
        public bool Create(Movie movie)
        {
            if (movie != null)
            {
                _context.Movies.Add(movie);
                _context.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// Method to upda movie comment.
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <param name="comment">holds comment.</param>
        /// <returns>return update movie details</returns>
        public Movie Update(int id,string userId, string comment)
        {
            var exisistingMovie = _context.Movies.Where(x => x.Id == id && x.UserId.Equals(userId,System.StringComparison.InvariantCultureIgnoreCase)).Select(x => x).FirstOrDefault();
            if (exisistingMovie != null)
            {
                exisistingMovie.Comments = comment;
                _context.SaveChanges();
            }
            return exisistingMovie;
        }
        /// <summary>
        /// Method to delete movie.
        /// </summary>
        /// <param name="id">holds movie id</param>
        /// <returns>return result</returns>
        public bool Remove(int id,string userId)
        {
            var exisistingMovie = _context.Movies.Where(x => x.Id == id && x.UserId.Equals(userId, System.StringComparison.InvariantCultureIgnoreCase)).Select(x => x).FirstOrDefault();
            if (exisistingMovie != null)
            {
                _context.Movies.Remove(exisistingMovie);
                _context.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
