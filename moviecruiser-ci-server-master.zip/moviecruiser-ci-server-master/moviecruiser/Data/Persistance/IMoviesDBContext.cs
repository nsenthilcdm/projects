﻿using Microsoft.EntityFrameworkCore;
using moviecruiser.Data.Models;

namespace moviecruiser.Data.Persistance
{
    /// <summary>
    /// interface contains signature methods for movie Db context.
    /// </summary>
    public interface IMoviesDBContext
    {
        /// <summary>
        /// Holds Dbset of movies
        /// </summary>
        DbSet<Movie> Movies { get; set; }
        /// <summary>
        /// Method savethe changes into DB.
        /// </summary>
        /// <returns></returns>
        int SaveChanges();
    }

}
