﻿using Microsoft.EntityFrameworkCore;
using moviecruiser.Data.Models;
using System;

namespace moviecruiser.Data.Persistance
{
    /// <summary>
    /// Class contains method for movies Db context.
    /// </summary>
    public class MoviesDBContext: DbContext,IMoviesDBContext
    {
        public MoviesDBContext() { }
        public MoviesDBContext(DbContextOptions<MoviesDBContext> options) : base(options) { this.Database.EnsureCreated(); }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Movie>()
                .HasKey(c => new { c.Id, c.UserId });
        }
        public DbSet<Movie> Movies { get; set; }
    }
}
