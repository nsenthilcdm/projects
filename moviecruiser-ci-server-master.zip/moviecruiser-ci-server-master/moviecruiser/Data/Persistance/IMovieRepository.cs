﻿using moviecruiser.Data.Models;
using System.Collections.Generic;

namespace moviecruiser.Data.Persistance
{
    /// <summary>
    /// Interface contains signature to manage movie details
    /// </summary>
    public interface IMovieRepository
    {
        /// <summary>
        /// Method to get all movies.
        /// </summary>
        /// <returns>returns movie list.</returns>
        List<Movie> GetAllMovies(string userId);
        /// <summary>
        /// Method to get movie by movie id
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <returns>returns movie detail</returns>
        Movie GetMovieById(int id, string userId);
        /// <summary>
        /// Method to create movie.
        /// </summary>
        /// <param name="movie">holds movie object</param>
        /// <returns>return success result</returns>
        bool Create(Movie movie);
        /// <summary>
        /// Method to upda movie comment.
        /// </summary>
        /// <param name="id">holds movie id.</param>
        /// <param name="comment">holds comment.</param>
        /// <returns>return update movie details</returns>
        Movie Update(int id, string userId, string comment);
        /// <summary>
        /// Method to delete movie.
        /// </summary>
        /// <param name="id">holds movie id</param>
        /// <returns>return result</returns>
        bool Remove(int id, string userId);
    }
}
