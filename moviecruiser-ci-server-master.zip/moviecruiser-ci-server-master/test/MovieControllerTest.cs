﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using moviecruiser.Controllers;
using moviecruiser.Data.Models;
using moviecruiser.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace test
{
    public class MovieControllerTest
    {
        [Fact]
        public void GetMethodWithOutParameter_ShouldReturnAllMovies()
        {
            var mockService =new  Mock<IMovieService>();
            mockService.Setup(service => service.GetAllMovies()).Returns(this.GetAllMovies());
            var controller = new MovieController(mockService.Object);
            var result = controller.Get();
            var actionresult= Assert.IsAssignableFrom<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<Movie>>(actionresult.Value);
        }
        [Fact]
        public void GetMethodWithParameter_ShouldReturnAMovie()
        {
            var mockService = new Mock<IMovieService>();
            mockService.Setup(service => service.GetMovieById(354440)).Returns(this.GetMovieById(354440));
            var controller = new MovieController(mockService.Object);
            var result = controller.Get(354440);
            var actionresult = Assert.IsAssignableFrom<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Movie>(actionresult.Value);
        }
        [Fact]
        public void GetMethodWithParameter_ShouldReturnNull()
        {
            var mockService = new Mock<IMovieService>();
            mockService.Setup(service => service.GetMovieById(354)).Returns(this.GetMovieById(354));
            var controller = new MovieController(mockService.Object);
            var result = controller.Get(354);
            var actionresult = Assert.IsAssignableFrom<NotFoundObjectResult>(result);
        }
        [Fact]
        public void PostMethod_ShouldCreateAMovie()
        {
            var mockService = new Mock<IMovieService>();
            Movie movie = new Movie { Id = 354440, Name = "SuperMan", Comments = string.Empty, PosterPath = "SuperMan.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 };
            mockService.Setup(service => service.CreateMovie(movie)).Returns(this.CreateMovie(movie));
            var controller = new MovieController(mockService.Object);
            var result = controller.Post(movie);
            var actionresult = Assert.IsAssignableFrom<CreatedAtActionResult>(result);
            Assert.True(Convert.ToBoolean(actionresult.Value));
        }
        [Fact]
        public void UpdateMovie_ShouldUpdateMovie()
        {
            var mockService = new Mock<IMovieService>();            
            mockService.Setup(service => service.UpdateMovie(354440, "testing")).Returns(this.UpdateMovie(354440, "testing"));
            var controller = new MovieController(mockService.Object);
            var result = controller.Put(354440, "testing");
            var actionresult = Assert.IsAssignableFrom<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Movie>(actionresult.Value);
            Assert.Equal("testing", model.Comments);
        }
        [Fact]
        public void UpdateMovie_ShouldNotUpdateMovie()
        {
            var mockService = new Mock<IMovieService>();
            mockService.Setup(service => service.UpdateMovie(354, "testing")).Returns(this.UpdateMovie(354, "testing"));
            var controller = new MovieController(mockService.Object);
            var result = controller.Put(354, "testing");
            var actionresult = Assert.IsAssignableFrom<OkObjectResult>(result);
            Assert.Null(actionresult.Value);
        }
        [Fact]
        public void DeleteMovie_ShouldDeleteMovie()
        {
            var mockService = new Mock<IMovieService>();
            mockService.Setup(service => service.RemoveMovie(354440)).Returns(this.RemoveMovie(354440));
            var controller = new MovieController(mockService.Object);
            var result = controller.Delete(354440);
            var actionresult = Assert.IsAssignableFrom<OkObjectResult>(result);
            Assert.True(Convert.ToBoolean(actionresult.Value));
        }
        [Fact]
        public void DeleteMovie_ShouldNotDeleteMovie()
        {
            var mockService = new Mock<IMovieService>();
            mockService.Setup(service => service.RemoveMovie(354)).Returns(this.RemoveMovie(354));
            var controller = new MovieController(mockService.Object);
            var result = controller.Delete(354);
            var actionresult = Assert.IsAssignableFrom<NotFoundObjectResult>(result);
        }
        private List<Movie> GetAllMovies()
        {
            var Movies = new List<Movie>();
            Movies.Add(new Movie { Id = 354440, Name = "SuperMan", Comments = string.Empty, PosterPath = "SuperMan.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 });
            Movies.Add(new Movie { Id = 354441, Name = "Anconda", Comments = string.Empty, PosterPath = "Anconda.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 8.0, VoteCount = 1080 });
            Movies.Add(new Movie { Id = 354442, Name = "Independence day", Comments = string.Empty, PosterPath = "Independenceday.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 });
            return Movies;
        }
        private Movie GetMovieById(int id)
        {
            List<Movie> movies = GetAllMovies();
            return movies.Where(x => x.Id == id).Select(x => x).FirstOrDefault();
        }
        private bool CreateMovie(Movie movie)
        {
            List<Movie> movies = GetAllMovies();
            movies.Add(movie);
            return true;
        }
        private Movie UpdateMovie(int id, string comments)
        {
            List<Movie> movies = GetAllMovies();
            var updatMovie = movies.Where(x => x.Id == id).Select(x => x).FirstOrDefault();
            if (updatMovie != null)
                updatMovie.Comments = comments;
            return updatMovie;
        }
        private bool RemoveMovie(int id)
        {
            List<Movie> movies = GetAllMovies();
            var updatMovie = movies.Where(x => x.Id == id).Select(x => x).FirstOrDefault();
            if (updatMovie != null)
            {
                movies.Remove(updatMovie);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
