﻿using Microsoft.EntityFrameworkCore;
using moviecruiser.Data.Models;
using moviecruiser.Data.Persistance;
using System;
using System.Collections.Generic;

namespace test
{
    public class DatabaseFixture : IDisposable
    {
        private IEnumerable<Movie> Movies { get; set; }
        public IMoviesDBContext dbContext;
        public DatabaseFixture()
        {
            var options = new DbContextOptionsBuilder<MoviesDBContext>().UseInMemoryDatabase(databaseName: "MoviesDB").Options;
            dbContext = new MoviesDBContext(options);
            dbContext.Movies.Add(new Movie { Id = 354440,UserId="test", Name = "SuperMan", Comments = string.Empty, PosterPath = "SuperMan.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 });
            dbContext.Movies.Add(new Movie { Id = 354441, UserId = "test", Name = "Anconda", Comments = string.Empty, PosterPath = "Anconda.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 8.0, VoteCount = 1080 });
            dbContext.Movies.Add(new Movie { Id = 354442, UserId = "test", Name = "Independence day", Comments = string.Empty, PosterPath = "Independenceday.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 });
            dbContext.SaveChanges();
        }
        public void Dispose()
        {
            Movies = null;
            dbContext = null;
        }
    }
}
