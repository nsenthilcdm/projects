﻿using moviecruiser.Data.Models;
using moviecruiser.Data.Persistance;
using System.Collections.Generic;
using Xunit;

namespace test
{
    public class MovieRepositoryTest : IClassFixture<DatabaseFixture>
    {
        private readonly IMovieRepository _repo;
        DatabaseFixture _fixture;
        public MovieRepositoryTest(DatabaseFixture fixture)
        {
            _fixture = fixture;
            _repo = new MovieRepository(_fixture.dbContext);
        }
        [Fact]
        public void GetAllMovies_ShouldReturnListOfMovie()
        {
            var actual = _repo.GetAllMovies("test");
            Assert.IsAssignableFrom<List<Movie>>(actual);
            Assert.Equal(3, actual.Count);
        }
        [Fact]
        public void GetMovieById_ShouldReturnAMovie()
        {
            var actual = _repo.GetMovieById(354440, "test");
            Assert.IsAssignableFrom<Movie>(actual);
            Assert.Equal("SuperMan", actual.Name);
        }
        [Fact]
        public void GetMovieById_ShouldReturnNull()
        {
            var actual = _repo.GetMovieById(355, "test");
            Assert.Null(actual);
        }

        [Fact]
        public void CreateMovie_ShouldbeAdded()
        {
            Movie newMovie = new Movie { Id = 12345,UserId="test", Name = "testMovie", Comments = "comments", PosterPath = "Posterpath", ReleaseDate = "12-12-2018", VoteAverage = 10.8, VoteCount = 19 };
            _repo.Create(newMovie);
            Assert.NotNull(_repo.GetMovieById(12345, "test"));
        }
        [Fact]
        public void UpdateMovie_ShouldbeAdded()
        {            
            _repo.Update(354440, "test", "Testing Comment");
            var actual = _repo.GetMovieById(354440, "test");
            Assert.Equal("Testing Comment", actual.Comments);
        }
        [Fact]
        public void RemoveMovie_ShouldbeDeleted()
        {
            _repo.Remove(12345, "test");
            var actual = _repo.GetMovieById(12345, "test");
            Assert.Null(actual);
        }
    }
    
}
