﻿using Microsoft.AspNetCore.Http;
using Moq;
using moviecruiser.Data.Models;
using moviecruiser.Data.Persistance;
using moviecruiser.Services;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace test
{
    public class MovieServiceTest
    {
        [Fact]
        public void GetAllMovies_ShouldReturnListOfMovie()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            mockRepo.Setup(repo => repo.GetAllMovies("test")).Returns(this.GetAllMovies());
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.GetAllMovies();
            Assert.IsAssignableFrom<List<Movie>>(actual);
            Assert.NotNull(actual);
            Assert.Equal(3, actual.Count);
        }
        [Fact]
        public void GetMovieById_ShouldReturnAMovie()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            mockRepo.Setup(repo => repo.GetMovieById(354440,"test")).Returns(this.GetMovieById(354440));
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.GetMovieById(354440);
            Assert.NotNull(actual);
            Assert.Equal("SuperMan", actual.Name);
        }
        [Fact]
        public void GetMovieById_ShouldReturnNull()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            mockRepo.Setup(repo => repo.GetMovieById(354, "test")).Returns(this.GetMovieById(354));
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.GetMovieById(354);
            Assert.Null(actual);
        }
        [Fact]
        public void CreateMovie_ShouldCreateAMovie()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            Movie movie = new Movie { Id = 354440,UserId="test", Name = "SuperMan", Comments = string.Empty, PosterPath = "SuperMan.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 };
            mockRepo.Setup(repo => repo.Create(movie)).Returns(this.Create(movie));
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.CreateMovie(movie);
            Assert.True(actual);
        }
        [Fact]
        public void UpdateMovie_ShouldUpdateMovie()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            mockRepo.Setup(repo => repo.Update(354440, "test", "testing")).Returns(this.Update(354440, "testing"));
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.UpdateMovie(354440, "testing");
            Assert.Equal("testing",actual.Comments);
        }
        [Fact]
        public void UpdateMovie_ShouldNotUpdateMovie()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            mockRepo.Setup(repo => repo.Update(354, "test", "testing")).Returns(this.Update(354, "testing"));
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.UpdateMovie(354, "testing");
            Assert.Null(actual);
        }
        [Fact]
        public void DeleteMovie_ShouldDeleteMovie()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            mockRepo.Setup(repo => repo.Remove(354440, "test")).Returns(this.Remove(354440));
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.RemoveMovie(354440);
            Assert.True(actual);
        }
        [Fact]
        public void DeleteMovie_ShouldNotDeleteMovie()
        {
            var mockRepo = new Mock<IMovieRepository>();
            var httpContext = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var fakeUserId = "test";
            context.Request.Headers["userId"] = fakeUserId;
            httpContext.Setup(_ => _.HttpContext).Returns(context);
            mockRepo.Setup(repo => repo.Remove(354,"test")).Returns(this.Remove(354));
            var service = new MovieService(mockRepo.Object, httpContext.Object);
            var actual = service.RemoveMovie(354);
            Assert.False(actual);
        }
        private List<Movie> GetAllMovies()
        {
            var Movies = new List<Movie>();
            Movies.Add(new Movie { Id = 354440,UserId="test", Name = "SuperMan", Comments = string.Empty, PosterPath = "SuperMan.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 });
            Movies.Add(new Movie { Id = 354441, UserId = "test", Name = "Anconda", Comments = string.Empty, PosterPath = "Anconda.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 8.0, VoteCount = 1080 });
            Movies.Add(new Movie { Id = 354442, UserId = "test", Name = "Independence day", Comments = string.Empty, PosterPath = "Independenceday.jpeg", ReleaseDate = "12-10-2012", VoteAverage = 7.8, VoteCount = 980 });
            return Movies;
        }
        private Movie GetMovieById(int id)
        {
            List<Movie> movies = GetAllMovies();
            return movies.Where(x => x.Id == id).Select(x => x).FirstOrDefault();
        }
        private bool Create(Movie movie)
        {
            List<Movie> movies = GetAllMovies();
            movies.Add(movie);
            return true;
        }
        private Movie Update(int id,string comments)
        {
            List<Movie> movies = GetAllMovies();
            var updatMovie = movies.Where(x => x.Id == id).Select(x => x).FirstOrDefault();
            if (updatMovie != null)
                updatMovie.Comments = comments;
            return updatMovie;
        }
        private bool Remove(int id)
        {
            List<Movie> movies = GetAllMovies();
            var updatMovie = movies.Where(x => x.Id == id).Select(x => x).FirstOrDefault();
            if (updatMovie != null)
            {
                movies.Remove(updatMovie);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
