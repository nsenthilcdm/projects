import  {Source} from "./source";

export interface IArticle{
    source:Source;
    author:string;
    title:string;
    description:string;
    url:string;
    urlToImage:string;
    publishedAt:Date;
    content:string;
    isFavouriteArticle:boolean;
}