export interface IUser {
    userId:string;
    password:string;
    firstName:String;
    lastName:string;
}