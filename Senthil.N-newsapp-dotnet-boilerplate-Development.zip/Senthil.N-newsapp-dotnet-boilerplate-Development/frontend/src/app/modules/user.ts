import  {IUser} from "./user.interface";

export class User implements IUser {
    public userId:string;
    public password:string;
    public firstName:String;
    public lastName:string;
}