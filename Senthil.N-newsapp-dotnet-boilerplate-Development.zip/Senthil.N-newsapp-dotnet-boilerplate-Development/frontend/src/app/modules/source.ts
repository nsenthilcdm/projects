import  {ISource} from "./source.interface";

export class Source implements ISource {
    public id:string;
    public name:string;  
}