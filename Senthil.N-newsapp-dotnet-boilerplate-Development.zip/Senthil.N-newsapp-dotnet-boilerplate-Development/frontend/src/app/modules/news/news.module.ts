import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatButtonModule} from '@angular/material/button';
import { NewsThumbnailComponent } from './component/news-thumbnail/news-thumbnail.component';
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import { ContainerComponent } from './component/container/container.component';
import { NewstoolbarComponent } from './component/newstoolbar/newstoolbar.component';
import { FormsModule } from '@angular/forms';
import { RootContainerComponent } from './component/root-container/root-container.component';
import {NewsService} from './component/Service/news.service';
import {NewsRouterModule} from './news-router.module';
import {AuthService} from './component/Service/auth.service';
import {AuthguardService} from './component/Service/authguard.service';
import { LoginComponent } from './component/login/login.component';
import { UserRegistrationComponent } from './component/user-registration/user-registration.component';
import { SearchComponent } from './component/search/search.component';
import { FavouritesComponent } from './component/favourites/favourites.component';

@NgModule({
  declarations: [    
    NewsThumbnailComponent, ContainerComponent, RootContainerComponent, NewstoolbarComponent, LoginComponent, UserRegistrationComponent, SearchComponent, FavouritesComponent,
  ],
  providers:[
    NewsService,
    AuthService,
    AuthguardService
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    MatCardModule,
    MatButtonModule,     
    MatFormFieldModule,
    FormsModule,    
    NewsRouterModule,    
  ],
  exports:[
    NewsRouterModule,
    RootContainerComponent
  ]
})
export class NewsModule { }
