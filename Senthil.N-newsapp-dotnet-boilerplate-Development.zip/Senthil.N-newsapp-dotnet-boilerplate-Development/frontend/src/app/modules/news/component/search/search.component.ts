import { Component, OnInit } from '@angular/core';
import {Article} from '../../../article';
import {NewsService} from '../Service/news.service';
import {ActivatedRoute, ParamMap} from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

 articles: Array<Article>;
  articleTitle:string;

  constructor(private newsService:NewsService, private route:ActivatedRoute) { 
    this.articles=[];
   } 

  ngOnInit() {
    this.route.paramMap.subscribe((params:ParamMap)=>{
    let title= params.get('title');
    this.articleTitle=title;
    this.articles=[];
    this.newsService.searchArticles(this.articleTitle).subscribe((article)=>{           
      this.articles.push(...article); 
    },(error)=>{
      window.alert("No results found");
    });
  });
  }
}
