import { Component, OnInit } from '@angular/core';
import {AuthService} from './../Service/auth.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userId:string;
  password:string;
  constructor(private authsvc:AuthService,private router:Router) {
    
   }

  ngOnInit() {
  }

  RegisterUser(){     
    this.router.navigate(['news/user-registration']);
  }
  loginUser(){       
    this.authsvc.login(this.userId,this.password)
    .then(obj=>{
      if(obj!="unable to fetch token")
      {
        if(JSON.parse(obj).token){
        this.authsvc.setToken(JSON.parse(obj).token);
        this.authsvc.setUserId(this.userId);
        this.router.navigate(['news/Home']);
        }
        else
        {
          window.alert("User Not found");
        }
    }
    else
    {
      window.alert("User Not found");
    }
    });    
  }

}
