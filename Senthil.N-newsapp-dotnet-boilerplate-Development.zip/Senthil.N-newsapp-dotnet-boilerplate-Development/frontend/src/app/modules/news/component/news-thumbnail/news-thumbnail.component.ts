import { Component, OnInit,Input } from '@angular/core';
import { Article } from '../../../article';
import { NewsService } from '../Service/news.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'news-thumbnail',
  templateUrl: './news-thumbnail.component.html',
  styleUrls: ['./news-thumbnail.component.css']
})
export class NewsThumbnailComponent implements OnInit {
  @Input()
  article: Article; 
  isSelectedFavourtie:boolean;
  constructor(private newsService:NewsService, private route:ActivatedRoute, private router:Router) {
    this.router.routeReuseStrategy.shouldReuseRoute = function(){
      return false;
     }
   }

  ngOnInit() {
    this.newsService.getFavourtieArticleByTitle(this.article.title).subscribe((res)=>
    {        
      this.isSelectedFavourtie=true; 
    },(err)=>{
      if(err.status==404)
      {
        this.isSelectedFavourtie=false;
      }
    });           
  }
  addToFavourites()
{   
  this.newsService.addArticlesToFavourites(this.article)  
  .subscribe((res)=>{    
    this.router.navigate(['news/favourites']);
  },(err)=>{
    if(err.status==409)
    {
      window.alert("Already Added to favourites");
    }
    else{
      window.alert("error occured");
    }
  }
  );  
}
removeFromFavourties()
{   
  this.newsService.removeArticlesfromFavourties(this.article.title).subscribe((res)=>{
   // this.router.navigate(['news/HeadLines']);
   this.router.navigated = false;
   this.router.navigate([this.router.url]);
  });  
}
}