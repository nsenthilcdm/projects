import { Component, OnInit } from '@angular/core';
import { NewsService } from '../Service/news.service';
import { ActivatedRoute } from '@angular/router';
import { Article } from '../../../article';

@Component({
  selector: 'app-favourites',
  templateUrl: './favourites.component.html',
  styleUrls: ['./favourites.component.css']
})
export class FavouritesComponent implements OnInit {

  articles: Array<Article>;

   constructor(private newsService:NewsService, private route:ActivatedRoute) {
     this.articles=[];    
    }
 
  ngOnInit() {
    this.newsService.getFavourtieArticles().subscribe((res)=>{ 
      this.articles.push(...res);
    });
  }
}
