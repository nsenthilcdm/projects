import { Component, OnInit } from '@angular/core';
import {AuthService} from './../Service/auth.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-newstoolbar',
  templateUrl: './newstoolbar.component.html',
  styleUrls: ['./newstoolbar.component.css']
})
export class NewstoolbarComponent implements OnInit {
  public SearchString:string;
  constructor(private authsvc:AuthService,private router:Router) { }

  ngOnInit() {
  }
  logoutUser(){ 
    this.authsvc.deleteToken();
    this.router.navigate(['news/login']);
  } 
  searchArticle(){ 
    this.router.navigate(['/news/search',this.SearchString]);
    }
}
