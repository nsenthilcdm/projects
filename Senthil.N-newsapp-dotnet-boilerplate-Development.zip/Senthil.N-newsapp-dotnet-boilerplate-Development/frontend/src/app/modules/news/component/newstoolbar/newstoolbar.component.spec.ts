import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewstoolbarComponent } from './newstoolbar.component';

describe('NewstoolbarComponent', () => {
  let component: NewstoolbarComponent;
  let fixture: ComponentFixture<NewstoolbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewstoolbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewstoolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
