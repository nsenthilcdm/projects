import { Injectable } from '@angular/core';
import { Article } from '../../../article';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {map, catchError} from 'rxjs/operators';
import { NewsHttpClientService } from './news-http-client.service';
import { Source } from '../../../source';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  newsEndpoint:string;
  newsSearchEndpoint:string;
  newsFavouriteEndpoint:string;
  urlEndpoint:String;
  imgPath:string;
  apiKey:string;
  constructor(private http:HttpClient,private newsHttp:NewsHttpClientService) { 
    this.apiKey="apikey=4493b197f0c5431fac0347d529c3602d";
    this.newsEndpoint=" https://newsapi.org/v2/top-headlines?country=in&";
    this.newsSearchEndpoint="https://newsapi.org/v2/everything?q=";
    this.newsFavouriteEndpoint="http://localhost:8081/api/Article";      
    this.urlEndpoint="";
  }
  getArticles(type:string,page:number=1):Observable<Array<Article>>{     
    if(type=="" || type=="HeadLines" ||type==undefined ||type==null )
    {
       this.urlEndpoint=`${this.newsEndpoint}${this.apiKey}&page=${page}`    }
    else{
      this.urlEndpoint=`${this.newsEndpoint}category=${type}&${this.apiKey}&page=${page}`
    }    
          return this.http.get(`${this.urlEndpoint}`).pipe(
        map(this.pickArticles),
        map(this.mapArticles.bind(this)),
       // map(this.transformArticlesfavourties.bind(this))
      );
  }   
  getFavourtieArticleByTitle(title:string):Observable<Article>{
     const newsEndpoint=`${this.newsFavouriteEndpoint}/${title}`
      return this.newsHttp.get(newsEndpoint).pipe(        
          map(this.mapArticle.bind(this))        
       );
  } 
  searchArticles(query:string):Observable<Array<Article>>{
     const endpoint=`${this.newsSearchEndpoint}${query}&${this.apiKey}&language=en&page=1`
      return this.http.get(endpoint).pipe(
        map(this.pickArticles),
        map(this.mapArticles.bind(this))
      );
  } 
  pickArticles(response){
      return response["articles"]
  }
  getFavourtieArticles()
  {
       return this.newsHttp.get(this.newsFavouriteEndpoint).pipe(
        map((articles)=>{
              return this.mapArticles(articles,true);
        }),
        catchError((err)=>{
          return throwError(err);
        })
      );     
  }
  addArticlesToFavourites(article): Observable<any>
  {
      return this.newsHttp.post(this.newsFavouriteEndpoint,article).pipe(
        map((res)=>{
              return res;
        }),
        catchError((err)=>{
          return throwError(err);
      }));
  }
  
  removeArticlesfromFavourties(title:string): Observable<any>
  {      
      return this.newsHttp.delete(this.newsFavouriteEndpoint+"/"+title).pipe(
        map((res)=>{
              return res;
        }),
        catchError((err)=>{
          return throwError(err);
        }));
  }
    
  mapArticles(articles,isFavourtie:boolean=false)
  {
    return articles.map((article)=>{
        return this.mapArticle(article,isFavourtie);
    });
  }
    
  mapArticle(article,isFavourtie:boolean=false) {
      const tempArticle=new Article();
      tempArticle.author=article.author;
      tempArticle.title=article.title;
      tempArticle.content=article.content;
      tempArticle.description=article.description;
      tempArticle.publishedAt=article.publishedAt;
      tempArticle.source=article.source;
      tempArticle.url=article.url;
      tempArticle.urlToImage=article.urlToImage;
      tempArticle.isFavouriteArticle=isFavourtie;
      const tempsource=new Source();
      if(article.source!==null)
      {
        tempsource.id=article.source.id;
        tempsource.name=article.source.name;
      }
      tempArticle.source=tempsource;
      return tempArticle;
    }
}
