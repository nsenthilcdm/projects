import { TestBed } from '@angular/core/testing';

import { NewsHttpClientService } from './news-http-client.service';

describe('NewsHttpClientService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NewsHttpClientService = TestBed.get(NewsHttpClientService);
    expect(service).toBeTruthy();
  });
});
