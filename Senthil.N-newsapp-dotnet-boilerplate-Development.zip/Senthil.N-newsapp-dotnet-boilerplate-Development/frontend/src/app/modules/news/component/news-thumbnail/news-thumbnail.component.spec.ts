import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsThumbnailComponent } from './news-thumbnail.component';

describe('NewsThumbnailComponent', () => {
  let component: NewsThumbnailComponent;
  let fixture: ComponentFixture<NewsThumbnailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewsThumbnailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsThumbnailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
