import { Component, OnInit } from '@angular/core';
import { Article } from '../../../article';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {NewsService} from '../Service/news.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'news-root-container',
  templateUrl: './root-container.component.html',
  styleUrls: ['./root-container.component.css']
})
export class RootContainerComponent implements OnInit {  
  headarticles: Array<Article>;
  categoryarticles: Array<Article>;
  newsArtiles:string;

   constructor(private newsService:NewsService, private route:ActivatedRoute) {
     this.headarticles=[];
     this.categoryarticles=[];
     this.newsArtiles="";
     this.route.data.subscribe((data)=>{this.newsArtiles=data.category;});
    }
 

  ngOnInit() {
    this.headarticles=[];
    this.newsService.getArticles(this.newsArtiles).subscribe((res)=>{  
      this.headarticles.push(...res);
    });
    this.newsService.getArticles("general").subscribe((res)=>{  
      this.categoryarticles.push(...res);
    });
  }
  filterCategory(filterVal: any) {
    this.categoryarticles=[];
    this.newsService.getArticles(filterVal).subscribe((res)=>{  
      this.categoryarticles.push(...res);
    });
  } 
}
