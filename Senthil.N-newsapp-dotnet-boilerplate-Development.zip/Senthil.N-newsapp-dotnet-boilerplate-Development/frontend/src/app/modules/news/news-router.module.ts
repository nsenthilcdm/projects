import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import {RootContainerComponent} from './component/root-container/root-container.component';
import { AuthguardService } from './component/Service/authguard.service';
import { LoginComponent } from './component/login/login.component';
import { UserRegistrationComponent } from './component/user-registration/user-registration.component';
import { SearchComponent } from './component/search/search.component';
import { FavouritesComponent } from './component/favourites/favourites.component';

const newsRoutes: Routes =[ 
  { 
 path:'news',
 children:[
  {
    path:'',
    redirectTo:'/news/login',
    pathMatch:'full',    
  }, 
  {
    path:'login',
    component:LoginComponent,    
  }, 
  {
    path:'user-registration',
    component:UserRegistrationComponent,    
  },
 
  {
    path:'Home',
    component:RootContainerComponent,
    data:{
      category:'HeadLines'
    },
    canActivate:[AuthguardService]
  },
  // {
  //   path:'Sports',
  //   component:RootContainerComponent,
  //   data:{
  //     category:'Sports'
  //   },
  //   canActivate:[AuthguardService]
  // },
  // {
  //   path:'business',
  //   component:RootContainerComponent,
  //   data:{
  //     category:'business'
  //   },
  //   canActivate:[AuthguardService]
  // },
  // {
  //   path:'entertainment',
  //   component:RootContainerComponent,
  //   data:{
  //     category:'entertainment'
  //   },
  //   canActivate:[AuthguardService]
  // },
  // {
  //   path:'general',
  //   component:RootContainerComponent,
  //   data:{
  //     category:'general'
  //   },
  //   canActivate:[AuthguardService]
  // },
  // {
  //   path:'science',
  //   component:RootContainerComponent,
  //   data:{
  //     category:'science'
  //   },
  //   canActivate:[AuthguardService]
  // },
  // {
  //   path:'technology',
  //   component:RootContainerComponent,
  //   data:{
  //     category:'technology'
  //   },
  //   canActivate:[AuthguardService]
  // },
  {
    path:'search/:title',
    component:SearchComponent,  
    canActivate:[AuthguardService]  
  },
  {
    path:'favourites',
    component:FavouritesComponent,  
    canActivate:[AuthguardService]  
  },
 ]
}
];

@NgModule({
  imports: [
    RouterModule.forChild(newsRoutes),
  ],
  exports: [
    RouterModule,
  ]
})
export class  NewsRouterModule { }
