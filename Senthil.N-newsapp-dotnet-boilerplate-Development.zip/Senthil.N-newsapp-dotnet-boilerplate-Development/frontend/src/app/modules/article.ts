import  {IArticle} from "./article.interface";
import  {Source} from "./source";

export class Article implements IArticle {
    public source:Source;
    public author:string;
    public title:string;
    public description:string;
    public url:string;
    public urlToImage:string;
    public publishedAt:Date;
    public content:string;
    public isFavouriteArticle:boolean;
}