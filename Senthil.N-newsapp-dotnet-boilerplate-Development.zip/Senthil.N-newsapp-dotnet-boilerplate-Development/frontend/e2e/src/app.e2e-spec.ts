import { AppPage } from './app.po';
import { browser, logging, by, element } from 'protractor';
import { protractor } from 'protractor/built/ptor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();   
   expect(browser.getTitle()).toEqual('News Online');
  });
  it('should be redirected to login page on opening of application',()=> {
    expect(browser.getCurrentUrl()).toContain('/login');
  });
  it('should be redirected to register page on clicking register button',()=> {
    browser.element(by.id('register')).click()
    expect(browser.getCurrentUrl()).toContain('/user-registration');
  } );
  it('Should be able to register',()=> {
    browser.element(by.name('fname')).sendKeys('fname');
    browser.element(by.name('lname')).sendKeys('lname');
    browser.element(by.name('uid')).sendKeys('user2');
    browser.element(by.name('psw')).sendKeys('password2');    
    browser.element(by.className('registerbtn')).click(); 
    expect(browser.getCurrentUrl()).toContain('/login');
  });
  it('Should be able to login',()=> {
    browser.element(by.name('userid')).sendKeys('user2');
    browser.element(by.name('password')).sendKeys('password2');    
    browser.element(by.id('login')).click();     
    browser.driver.sleep(1000); 
    expect(browser.getCurrentUrl()).toContain('/Home');    
  } ); 
  it('Should be able to add favourties',()=> {       
    const searchItems=element.all(by.name('addfavourite')); 
    searchItems.get(0).click();
    browser.waitForAngular();  
    expect(browser.getCurrentUrl()).toContain('/favourites');     
  });
  it('Should be able to remove from favourties',()=> {      
    const searchItems=element.all(by.name('removefavourite')); 
    searchItems.get(0).click();
    expect(browser.getCurrentUrl()).toContain('/favourites'); 
    browser.waitForAngular();  
  });
  
  it('Should be able to search articles',()=> {    
    browser.element(by.id('search')).sendKeys('john');
    browser.element(by.id('search')).sendKeys(protractor.Key.ENTER);    
    browser.waitForAngular();
    const searchItems=element.all(by.className('example-card')); 
    //expect(searchItems.count()).toBe(20);
    browser.waitForAngular();
    expect(browser.getCurrentUrl()).toContain('/search/john');   
    // for(let i=0;i<1;i=i+1){
    // expect(searchItems.get(i).getText()).toContain('super');
    // }    
  });
  it('Should be able to logout',()=> {    
    browser.element(by.id('logout')).click();
    browser.waitForAngular();
    expect(browser.getCurrentUrl()).toContain('/login');  
    browser.driver.sleep(1000); 
  });
  // afterEach(async () => {
  //   // Assert that there are no errors emitted from the browser
  //   const logs = await browser.manage().logs().get(logging.Type.BROWSER);
  //   expect(logs).not.toContain(jasmine.objectContaining({
  //     level: logging.Level.SEVERE,
  //   } as logging.Entry));
  // });
});
