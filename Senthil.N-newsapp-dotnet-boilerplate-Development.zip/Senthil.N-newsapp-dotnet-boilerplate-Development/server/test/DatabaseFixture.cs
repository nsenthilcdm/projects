﻿using Microsoft.EntityFrameworkCore;
using server.Data.Persistance;
using server.Data.Models;
using System;
using System.Collections.Generic;

namespace test
{
    public class DatabaseFixture : IDisposable
    {
        private IEnumerable<Article> Articles { get; set; }
        public IArticleDBContext dbContext;
        public DatabaseFixture()
        {
            var options = new DbContextOptionsBuilder<ArticleDBContext>().UseInMemoryDatabase(databaseName: "NewsDB").Options;
            dbContext = new ArticleDBContext(options);            
            dbContext.Articles.Add(new Article { author = "Karthik", Content = "content1", Description = "articel about sports", PublishedAt = "08/01/2019", Title = "The sports", source = new Source { id = "", name = "timesofindia" }, url = "usl", UrlToImage = "image.jpg", UserId = "test", });
            dbContext.Articles.Add(new Article { author = "Kev", Content = "content2", Description = "articel about religion", PublishedAt = "08/01/2019", Title = "The religion", source = new Source { id = "", name = "yourtube" }, url = "usl", UrlToImage = "youtube.jpg", UserId = "test", });
            dbContext.Articles.Add(new Article { author = "Muthu", Content = "content3", Description = "articel about political", PublishedAt = "08/01/2019", Title = "The politics", source = new Source { id = "", name = "thehindu" }, url = "usl", UrlToImage = "hindu.jpg",UserId = "test", });
            dbContext.SaveChanges();
        }
        public void Dispose()
        {
            Articles = null;
            dbContext = null;
        }
    }
}
