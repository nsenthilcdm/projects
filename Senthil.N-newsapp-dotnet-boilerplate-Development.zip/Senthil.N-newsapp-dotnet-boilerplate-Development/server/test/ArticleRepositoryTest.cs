﻿using server.Data.Models;
using server.Data.Persistance;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace test
{
    public class ArticleRepositoryTest: IClassFixture<DatabaseFixture>
    {
        private readonly IArticleRepository _repo;
        DatabaseFixture _fixture;
        public ArticleRepositoryTest(DatabaseFixture fixture)
        {
            _fixture = fixture;
            _repo = new ArticleRepository(_fixture.dbContext);
        }
        [Fact]
        public void GetAllArticles_ShouldReturnListOfArticle()
        {
            var actual = _repo.GetAllArticles("test");
            Assert.IsAssignableFrom<List<Article>>(actual);
            Assert.Equal(4, actual.Count);
        }
        [Fact]
        public void GetArticleByTitle_ShouldReturnAArticle()
        {
            var actual = _repo.GetArticleByTitle("The religion", "test");
            Assert.IsAssignableFrom<Article>(actual);
            Assert.Equal("Kev", actual.author);
        }
        [Fact]
        public void GetArticleById_ShouldReturnNull()
        {
            var actual = _repo.GetArticleByTitle("dummy", "test");
            Assert.Null(actual);
        }

        [Fact]
        public void CreateArticle_ShouldbeAdded()
        {
            Article newArticle = new Article { author = "kathir", Content = "content1", Description = "articel about sports", PublishedAt = "08/01/2019", Title = "The farm", source = new Source { id = "", name = "timesofindia" }, url = "usl", UrlToImage = "image.jpg",UserId="test" };
            _repo.Create(newArticle);
            Assert.NotNull(_repo.GetArticleByTitle("The farm", "test"));
        }

        [Fact]
        public void RemoveArticle_ShouldbeDeleted()
        {
            _repo.Remove("The politics", "test");
            var actual = _repo.GetArticleByTitle("The politics", "test");
            Assert.Null(actual);
        }

    }
}
