﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using server.Controllers;
using server.Data.Models;
using server.Data.Persistance;
using server.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace test
{
    public class ArticleControllerTest
    {
        [Fact]
        public void GetMethodWithOutParameter_ShouldReturnAllArticles()
        {
            var mockService = new Mock<IArticleService>();
            mockService.Setup(service => service.GetAllArticles()).Returns(this.GetAllArticles());
            var controller = new ArticleController(mockService.Object);
            var result = controller.Get();
            var actionresult = Assert.IsAssignableFrom<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<IEnumerable<Article>>(actionresult.Value);
        }
        [Fact]
        public void GetMethodWithParameter_ShouldReturnAArticle()
        {
            var mockService = new Mock<IArticleService>();
            mockService.Setup(service => service.GetArticleByTitle("The religion")).Returns(this.GetArticleByTitle("The religion"));
            var controller = new ArticleController(mockService.Object);
            var result = controller.Get("The religion");
            var actionresult = Assert.IsAssignableFrom<OkObjectResult>(result);
            var model = Assert.IsAssignableFrom<Article>(actionresult.Value);
        }
        [Fact]
        public void GetMethodWithParameter_ShouldReturnNull()
        {
            var mockService = new Mock<IArticleService>();
            mockService.Setup(service => service.GetArticleByTitle("the fan")).Returns(this.GetArticleByTitle("the fan"));
            var controller = new ArticleController(mockService.Object);
            var result = controller.Get("the fan");
            var actionresult = Assert.IsAssignableFrom<NotFoundObjectResult>(result);
        }
        [Fact]
        public void PostMethod_ShouldCreateAArticle()
        {
            var mockService = new Mock<IArticleService>();
            Article newArticle = new Article { author = "kathir", Content = "content1", Description = "articel about sports", PublishedAt = "08/01/2019", Title = "The farm", source =new Source { id="",name="timesofindia"}, url = "usl", UrlToImage = "image.jpg", UserId = "test" };
            mockService.Setup(service => service.CreateArticle(newArticle)).Returns(this.CreateArticle(newArticle));
            var controller = new ArticleController(mockService.Object);
            var result = controller.Post(newArticle);
            var actionresult = Assert.IsAssignableFrom<CreatedAtActionResult>(result);
            Assert.True(Convert.ToBoolean(actionresult.Value));
        }
       
        [Fact]
        public void DeleteArticle_ShouldDeleteArticle()
        {
            var mockService = new Mock<IArticleService>();
            mockService.Setup(service => service.RemoveArticle("The religion")).Returns(this.RemoveArticle("The religion"));
            var controller = new ArticleController(mockService.Object);
            var result = controller.Delete("The religion");
            var actionresult = Assert.IsAssignableFrom<OkObjectResult>(result);
            Assert.True(Convert.ToBoolean(actionresult.Value));
        }
        [Fact]
        public void DeleteArticle_ShouldNotDeleteArticle()
        {
            var mockService = new Mock<IArticleService>();
            mockService.Setup(service => service.RemoveArticle("The fan")).Returns(this.RemoveArticle("The fan"));
            var controller = new ArticleController(mockService.Object);
            var result = controller.Delete("The fan");
            var actionresult = Assert.IsAssignableFrom<NotFoundObjectResult>(result);
        }
        private List<Article> GetAllArticles()
        {
            var Articles = new List<Article>();
            Articles.Add(new Article { author = "Karthik", Content = "content1", Description = "articel about sports", PublishedAt = "08/01/2019", Title = "The sports", source = new Source { id = "", name = "timesofindia" }, url = "usl", UrlToImage = "image.jpg", UserId = "test", });
            Articles.Add(new Article { author = "Kev", Content = "content2", Description = "articel about religion", PublishedAt = "08/01/2019", Title = "The religion", source = new Source { id = "", name = "youtube" }, url = "usl", UrlToImage = "youtube.jpg", UserId = "test", });
            Articles.Add(new Article { author = "Muthu", Content = "content3", Description = "articel about political", PublishedAt = "08/01/2019", Title = "The politics", source = new Source { id = "", name = "thehindu" }, url = "usl", UrlToImage = "hindu.jpg", UserId = "test", });
            return Articles;
        }
        private Article GetArticleByTitle(string title)
        {
            List<Article> Articles = GetAllArticles();
            return Articles.Where(x => x.Title == title).Select(x => x).FirstOrDefault();
        }
        private bool CreateArticle(Article Article)
        {
            List<Article> Articles = GetAllArticles();
            Articles.Add(Article);
            return true;
        }
       
        private bool RemoveArticle(string title)
        {
            List<Article> Articles = GetAllArticles();
            var updatArticle = Articles.Where(x => x.Title == title).Select(x => x).FirstOrDefault();
            if (updatArticle != null)
            {
                Articles.Remove(updatArticle);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
