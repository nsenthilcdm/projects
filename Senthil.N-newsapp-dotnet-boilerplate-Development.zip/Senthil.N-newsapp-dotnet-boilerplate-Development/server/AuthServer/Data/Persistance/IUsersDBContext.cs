﻿using AuthServer.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace AuthServer.Data.Persistance
{
    public interface IUsersDBContext
    {
        /// <summary>
        /// Holds Dbset of users
        /// </summary>
        DbSet<User> Users { get; set; }
        /// <summary>
        /// Method savethe changes into DB.
        /// </summary>
        /// <returns></returns>
        int SaveChanges();
    }
}
