﻿using AuthServer.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthServer.Data.Persistance
{
    public class UsersDBContext : DbContext, IUsersDBContext
    {
        public UsersDBContext() { }
        public UsersDBContext(DbContextOptions<UsersDBContext> options) : base(options) { this.Database.EnsureCreated(); }

        public DbSet<User> Users { get; set; }
    }
}
