﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthServer.CustomException;
using AuthServer.Data.Models;
using AuthServer.Services;
using Microsoft.AspNetCore.Mvc;

namespace AuthServer.Controllers
{
    [Route("auth")]
    public class AuthController : Controller
    {
        private readonly IUserService _service;
        private readonly ITokenGenerator _tokenGenerator;
        
        public AuthController(IUserService service, ITokenGenerator tokenGenerator)
        {
            _service = service;
            _tokenGenerator = tokenGenerator;
        }
        [HttpPost]
        [Route("register")]
        public IActionResult Register([FromBody]User user)
        {
            try
            {
                if(_service.IsUserExists(user.UserId))
                {
                    return StatusCode(409, "A User Already exists with same userid");
                }
                else
                {
                    _service.Register(user);
                    return StatusCode(201, "User Registered successfully");
                }
            }
            catch(Exception ex)
            {
                return StatusCode(500,"Server error occurred");
            }
        }
        [HttpPost]
        [Route("login")]
        public IActionResult login([FromBody]User user)
        {
            try
            {
                string userid = user.UserId;
                string password = user.Password;
                User _user = _service.Login(userid, password);
                string value = _tokenGenerator.GetJWTToken(_user.UserId);
                return Ok(value);
            }
            catch(UserNotFoundException ufx)
            {
                return NotFound(ufx.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Server error occurred");
            }
        }
    }
}
