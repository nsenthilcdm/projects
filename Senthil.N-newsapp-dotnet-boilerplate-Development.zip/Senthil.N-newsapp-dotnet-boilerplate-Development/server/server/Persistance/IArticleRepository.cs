﻿using server.Data.Models;
using System.Collections.Generic;

namespace server.Data.Persistance
{
    /// <summary>
    /// Interface contains signature to manage article details
    /// </summary>
    public interface IArticleRepository
    {
        /// <summary>
        /// Method to get all articles.
        /// </summary>
        /// <returns>returns article list.</returns>
        List<Article> GetAllArticles(string userId);
        /// <summary>
        /// Method to get article by article id
        /// </summary>
        /// <param name="title">holds title.</param>
        /// <returns>returns article detail</returns>
        Article GetArticleByTitle(string title, string userId);
        /// <summary>
        /// Method to create article.
        /// </summary>
        /// <param name="article">holds article object</param>
        /// <returns>return success result</returns>
        bool Create(Article article);
        /// <summary>
        /// Method to delete article.
        /// </summary>
        /// <param name="title">holds article title</param>
        /// <returns>return result</returns>
        bool Remove(string title, string userId);
    }
}
