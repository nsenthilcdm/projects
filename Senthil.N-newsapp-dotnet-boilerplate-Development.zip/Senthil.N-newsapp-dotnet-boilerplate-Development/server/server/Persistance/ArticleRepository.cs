﻿using server.Data.Models;
using System.Collections.Generic;
using System.Linq;

namespace server.Data.Persistance
{
    /// <summary>
    /// Class contains method to manage Articles.
    /// </summary>
    public class ArticleRepository : IArticleRepository
    {
        private readonly IArticleDBContext _context;

        /// <summary>
        /// Contructor to initiliaze DB context
        /// </summary>
        /// <param name="context">holds Db context.</param>
        public ArticleRepository(IArticleDBContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Method to get all articles.
        /// </summary>
        /// <returns>returns article list.</returns>
        public List<Article> GetAllArticles(string userId)
        {
            return _context.Articles.Where(x=>x.UserId.Equals(userId, System.StringComparison.InvariantCultureIgnoreCase)).Select(x => x).ToList();
        }
        /// <summary>
        /// Method to get article by article id
        /// </summary>
        /// <param name="title">holds title.</param>
        /// <returns>returns article detail</returns>
        public Article GetArticleByTitle(string title,string userId)
        {
            return _context.Articles.Where(x => x.Title == title && x.UserId.Equals(userId, System.StringComparison.InvariantCultureIgnoreCase)).Select(x => x).FirstOrDefault();
        }
        /// <summary>
        /// Method to create article.
        /// </summary>
        /// <param name="article">holds article object</param>
        /// <returns>return success result</returns>
        public bool Create(Article article)
        {
            if (article != null)
            {
                _context.Articles.Add(article);
                _context.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// Method to delete Article.
        /// </summary>
        /// <param name="title">Holds the title</param>
        /// <param name="userId">holds the userid</param>
        /// <returns>return result</returns>
        public bool Remove(string title,string userId)
        {
            var exisistingArticle = _context.Articles.Where(x => x.Title == title && x.UserId.Equals(userId, System.StringComparison.InvariantCultureIgnoreCase)).Select(x => x).FirstOrDefault();
            if (exisistingArticle != null)
            {
                _context.Articles.Remove(exisistingArticle);
                _context.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
