﻿using Microsoft.EntityFrameworkCore;
using server.Data.Models;

namespace server.Data.Persistance
{
    /// <summary>
    /// interface contains signature methods for article Db context.
    /// </summary>
    public interface IArticleDBContext
    {
        /// <summary>
        /// Holds Dbset of articles
        /// </summary>
        DbSet<Article> Articles { get; set; }
        /// <summary>
        /// Method savethe changes into DB.
        /// </summary>
        /// <returns></returns>
        int SaveChanges();
    }

}
