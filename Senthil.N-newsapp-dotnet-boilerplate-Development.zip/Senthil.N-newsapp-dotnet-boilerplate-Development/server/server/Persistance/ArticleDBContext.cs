﻿using Microsoft.EntityFrameworkCore;
using server.Data.Models;
using System;

namespace server.Data.Persistance
{
    /// <summary>
    /// Class contains method for Articles Db context.
    /// </summary>
    public class ArticleDBContext: DbContext,IArticleDBContext
    {
        public ArticleDBContext() { }
        public ArticleDBContext(DbContextOptions<ArticleDBContext> options) : base(options) {
            try
            {
                this.Database.EnsureCreated();
            }
            catch (Exception ex)
            {
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Article>()
                .HasKey(c => new { c.Title, c.UserId });
        }
        public DbSet<Article> Articles { get; set; }
    }
}
