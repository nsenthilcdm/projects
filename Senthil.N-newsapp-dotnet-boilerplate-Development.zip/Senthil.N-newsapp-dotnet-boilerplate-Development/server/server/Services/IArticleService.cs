﻿using server.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Services
{
    /// <summary>
    /// Service interface contains rapper methods for repository.
    /// </summary>
    public interface IArticleService
    {
        /// <summary>
        /// Method to get all Articles.
        /// </summary>
        /// <returns>returns articles.</returns>
        List<Article> GetAllArticles();
        /// <summary>
        /// Method to get article by title
        /// </summary>
        /// <param name="title">holds title.</param>
        /// <returns>returns articles</returns>
        Article GetArticleByTitle(string title);
        /// <summary>
        /// Method to create article.
        /// </summary>
        /// <param name="article">holds article object</param>
        /// <returns>return success result</returns>
        bool CreateArticle(Article article);

        /// <summary>
        /// Method to delete article.
        /// </summary>
        /// <param name="title">holds title</param>
        /// <returns>return result</returns>
        bool RemoveArticle(string title);
    }
}
