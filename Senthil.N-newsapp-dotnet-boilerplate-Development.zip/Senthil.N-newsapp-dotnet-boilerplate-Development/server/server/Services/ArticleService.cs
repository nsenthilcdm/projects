﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using server.Data.Persistance;
using server.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Services
{
    public class ArticleService:IArticleService
    {
        private readonly IArticleRepository _repo;
        private StringValues userId = new StringValues();
        public ArticleService(IArticleRepository repo, IHttpContextAccessor contextAccessor)
        {
            _repo = repo;
            var context = contextAccessor;
            context.HttpContext.Request.Headers.TryGetValue("userId", out userId);
        }
        /// <summary>
        /// Method to create article.
        /// </summary>
        /// <param name="article">holds article object</param>
        /// <returns>return success result</returns>
        public bool CreateArticle(Article article)
        {
            if(string.IsNullOrWhiteSpace(this.userId))
            {
                return false;
            }
            article.UserId = this.userId;
            return _repo.Create(article);
        }
        /// <summary>
        /// Method to get all articles.
        /// </summary>
        /// <returns>returns article list.</returns>
        public List<Article> GetAllArticles()
        {
            return _repo.GetAllArticles(this.userId);
        }
        /// <summary>
        /// Method to get article by title
        /// </summary>
        /// <param name="title">holds title.</param>
        /// <returns>returns article detail</returns>
        public Article GetArticleByTitle(string title)
        {
            return _repo.GetArticleByTitle(title, this.userId);
        }
        /// <summary>
        /// Method to delete article.
        /// </summary>
        /// <param name="title">holds title</param>
        /// <returns>return result</returns>
        public bool RemoveArticle(string title)
        {
            return _repo.Remove(title, this.userId);
        }       
    }
}
