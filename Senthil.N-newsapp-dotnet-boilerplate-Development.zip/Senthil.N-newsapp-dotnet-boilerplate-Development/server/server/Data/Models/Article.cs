﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace server.Data.Models
{
    public class Article
    {      
        /// <summary>
        /// Gets or sets user id
        /// </summary>
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(Order = 1)]
        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }
        /// <summary>
        /// Gets or sets title
        /// </summary>
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column(Order = 2)]
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }
        /// <summary>
        /// Gets or sets source name
        /// </summary>        
        [Column(Order = 3)]
        [JsonProperty(PropertyName = "source")]
        public Source source { get; set; }
        /// <summary>
        /// Gets or sets author
        /// </summary>
        [Column(Order = 4)]
        [JsonProperty(PropertyName = "author")]
        public string author { get; set; }

        /// <summary>
        /// Gets or sets description
        /// </summary>
        [Column(Order = 5)]
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets url
        /// </summary>
        [Column(Order = 6)]
        [JsonProperty(PropertyName = "url")]
        public string url { get; set; }
        /// <summary>
        /// Gets or sets url to image
        /// </summary>
        [Column(Order = 7)]
        [JsonProperty(PropertyName = "urlToImage")]
        public string UrlToImage { get; set; }
        /// <summary>
        /// Gets or sets Published at
        /// </summary>
        [Column(Order = 8)]
        [JsonProperty(PropertyName = "publishedAt")]
        public string PublishedAt { get; set; }
        /// <summary>
        /// Gets or sets content
        /// </summary>
        [Column(Order = 9)]
        [JsonProperty(PropertyName = "content")]
        public string Content { get; set; }
    }
    public class Source
    {
        /// <summary>
        /// Gets or sets content
        /// </summary>
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key, Column(Order = 0)]
        public int SourceId { get; set; }
        /// <summary>
        /// Gets or sets content
        /// </summary>
        [Column(Order = 1)]
        [JsonProperty(PropertyName = "id")]
        public string id { get; set; }
        /// <summary>
        /// Gets or sets content
        /// </summary>
        [Column(Order = 2)]
        [JsonProperty(PropertyName = "name")]        
        public string name { get; set; }
    }
}
