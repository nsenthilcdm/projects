﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using server.Data.Models;
using server.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace server.Controllers
{    
    [Authorize]
    [Route("api/[controller]")]
    public class ArticleController: Controller
    {
        private readonly IArticleService _service;
        /// <summary>
        /// Constructor to initialize the article service.
        /// </summary>
        /// <param name="service"></param>
        public ArticleController(IArticleService service)
        {
            _service = service;
        }
        // GET: api/<controller>
        /// <summary>
        /// Get method to get all the article details.
        /// </summary>
        /// <returns>return new article list</returns>
        [HttpGet]
        public ActionResult Get()
        {
            try
            {
                List<Article> articles = _service.GetAllArticles();
                return Ok(articles);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        // GET api/<controller>/5
        /// <summary>
        /// Method to get news article by title
        /// </summary>
        /// <param name="title">holds title</param>
        /// <returns>returns the article record.</returns>
        [HttpGet("{title}")]
        public ActionResult Get(string title)
        {
            try
            {
                Article article = _service.GetArticleByTitle(title);
                if (article == null)
                {
                    return NotFound("Record not found");
                }
                else
                {
                    return Ok(article);
                }
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }

        // POST api/<controller>
        /// <summary>
        /// Post method to create a article.
        /// </summary>
        /// <param name="value">holds the article details.</param>
        /// <returns>returns success message</returns>
        [HttpPost]
        public ActionResult Post([FromBody]Article value)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(value);
                Article article = _service.GetArticleByTitle(value.Title);
                if (article == null)
                {
                    bool result = _service.CreateArticle(value);
                    return CreatedAtAction("Post", result);
                }
                else
                {
                    return StatusCode(409);
                }
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }



        // DELETE api/<controller>/5
        /// <summary>
        /// Method to delete the article.
        /// </summary>
        /// <param name="title">holds the title to be deleted.</param>
        /// <returns>returns ok message.</returns>
        [HttpDelete("{title}")]
        public ActionResult Delete(string title)
        {
            try
            {
                if (_service.RemoveArticle(title))
                {
                    return Ok(true);
                }
                else
                {
                    return NotFound("Record not found");
                }
            }
            catch (InvalidOperationException ex)
            {
                return NotFound("not found error");
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized();
            }
            catch (Exception ex)
            {
                return StatusCode(500);
            }
        }
    }
}
