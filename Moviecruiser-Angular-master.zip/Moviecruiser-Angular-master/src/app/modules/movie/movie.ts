import  {IMovie} from "./movie.interface";

export class Movie implements IMovie {
    public id:number;
    public title:string;
    public poster_path:string;
    public overview:String;
    public release_date:string;
    public comments:string;
    public vote_average:string;
    public vote_count:string;
    public isWatchListedMovie:boolean;
}