export interface IMovie {
    id:number;
    title:string;
    poster_path:string;
    overview:String;
    release_date:string;
    comments:string;
    vote_average:string;
    vote_count:string;
    isWatchListedMovie:boolean;
}