import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import {ContainerComponent} from './component/container/container.component';
import {TmdbContainerComponent} from './component/tmdb-container/tmdb-container.component';
import { WatchlistComponent } from './component/watchlist/watchlist.component';
import { SearchComponent } from './component/search/search.component';
import { MoviedetailComponent } from './component/moviedetail/moviedetail.component';
import { LoginComponent } from './component/login/login.component';
import { AuthGuardService } from './component/Service/auth-guard.service';
import {UserRegistrationComponent} from './component/user-registration/user-registration.component';


const movieRoutes: Routes =[ 
  { 
 path:'movies',
 children:[
  {
    path:'',
    redirectTo:'/movies/login',
    pathMatch:'full',    
  }, 
  {
    path:'login',
    component:LoginComponent,    
  },
  {
    path:'user-registration',
    component:UserRegistrationComponent,    
  },
  {
    path:'popular',
    component:TmdbContainerComponent,
    data:{
      movieType:'popular',
    },
    canActivate:[AuthGuardService]
  },
  {
    path:'top_rated',
    component:TmdbContainerComponent,
    data:{
      movieType:'top_rated',
    },
    canActivate:[AuthGuardService]
  },
  {
    path:'watchlist',
    component:WatchlistComponent,  
    canActivate:[AuthGuardService]  
  },
  {
    path:'search/:title',
    component:SearchComponent,  
    canActivate:[AuthGuardService]  
  },
  {
    path:'popular',
    component:TmdbContainerComponent,
    data:{
      movieType:'popular',
    },
    canActivate:[AuthGuardService]
  }
 ]
},
{
  path:'movies/:id',component:MoviedetailComponent,  
  canActivate:[AuthGuardService]
}
];
@NgModule({
  imports: [
    RouterModule.forChild(movieRoutes),
  ],
  exports: [
    RouterModule,
  ]
})
export class MovieRouterModule { }
