import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {AuthService} from './../Service/auth.service';
import { User } from '../../user';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
  user: User= {
    "userId": "",
    "firstName": "",
    "password":"",
    "lastName":""
};
  constructor(private authsvc:AuthService,private router:Router) { }

  ngOnInit() {
  }
  LoginUser(){     
    this.router.navigate(['movies/login']);
  }
  RegisterUser(userDetail:User)
  {   
    if(userDetail.userId.replace(/\s/g, "")!="" && userDetail.password.replace(/\s/g, "")!=""
    && userDetail.firstName.replace(/\s/g, "")!="" 
    && userDetail.lastName.replace(/\s/g, "")!="" 
    )
    {
    this.authsvc.RegisterUser(userDetail)
    .then(obj=>{
     if(obj=="409")
     {
      window.alert("Userid already exisist.");
     }
     else if(obj=="User Registered successfully")
     {
     // window.alert("User Registered successfully.");
      this.router.navigate(['movies/login']);
     }
     else{
      window.alert("User Creation failed.");
     }
    });   
  }
  else
  {
    window.alert("All fields are mandatory.");
  }
  }  
}
