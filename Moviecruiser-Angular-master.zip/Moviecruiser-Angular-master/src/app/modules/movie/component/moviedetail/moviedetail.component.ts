import { Component, OnInit, Input } from '@angular/core';
import {Movie} from '../../movie';
import {MovieService} from '../Service/movie.service';
import {ActivatedRoute,Router} from '@angular/router';
import { IMovie } from '../../movie.interface';


@Component({
  selector: 'movie-moviedetail',
  templateUrl: './moviedetail.component.html',
  styleUrls: ['./moviedetail.component.css']
})
export class MoviedetailComponent implements OnInit {
  movie: IMovie;
  show:boolean;
  public movieId;
  
  constructor(private movieService:MovieService, private route:ActivatedRoute, private router:Router) { 
    this.show=false;
   } 

  ngOnInit() {
    let id=parseInt(this.route.snapshot.paramMap.get('id'));
    this.movieId=id;
    this.movieService.getWatchListMovieById(this.movieId).subscribe((movie)=>
    {  
      this.movie=movie; 
    },(err)=>{
      if(err.status==404)
      {
        this.movieService.getTmdbMovieById(this.movieId).subscribe((movie)=>{
          this.movie=movie;
        },(error)=>{
              window.alert("no records found");
        });   
      }
      else{
        window.alert("no records found");
      }
    }); 
  }
  addToWatchList()
  {   
    this.movieService.addMovieToWatchList(this.movie).subscribe((res)=>{
      this.router.navigate(['movies/watchlist']);
    });
    
  }
  updateComments(movieDetail:IMovie)
  {   
    this.movieService.updateComments(movieDetail).subscribe((res)=>{
     this.show=true;
    });    
  }
  removeFromWatchList()
  {   
    this.movieService.removeMoviefromWatchList(this.movie.id).subscribe((res)=>{
      this.router.navigate(['movies/watchlist']);
    });    
  }
}
