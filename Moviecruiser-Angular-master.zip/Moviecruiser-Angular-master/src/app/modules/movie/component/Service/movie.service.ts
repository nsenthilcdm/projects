import { Injectable } from '@angular/core';
import {map, catchError} from 'rxjs/operators';
import {Observable, throwError} from 'rxjs';
import { Movie } from '../../movie';
import { IMovie } from '../../movie.interface';
import {MoviehttpclientService} from '../Service/moviehttpclient.service';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { templateJitUrl } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})


export class MovieService {
  tmdbEndpoint:string;
  tmdbSearchEndpoint:string;
  imgPath:string;
  apiKey:string;
  watchListEndpoint:string;
  constructor(private httpMovie:MoviehttpclientService,private http:HttpClient) {
    this.apiKey="api_key=65590fec859e5999c2a0753454c64302";
    this.tmdbEndpoint="https://api.themoviedb.org/3/movie";
    this.imgPath="https://image.tmdb.org/t/p/w500"; 
    this.watchListEndpoint="http://localhost:50229/api/Movie";
    this.tmdbSearchEndpoint="https://api.themoviedb.org/3/search/movie";
  }
 
  getMovies(type:string,page:number=1):Observable<Array<Movie>>{
     const movieEndpoint=`${this.tmdbEndpoint}/${type}?${this.apiKey}&language=en-US&&page=${page}`
      return this.http.get(movieEndpoint).pipe(
        map(this.pickMovieResults),
        map(this.transformPosterPath.bind(this))
      );
  }    
  getTmdbMovieById(movie_Id:number):Observable<Movie>{
     const movieEndpoint=`${this.tmdbEndpoint}/${movie_Id}?${this.apiKey}&language=en-US`
      return this.http.get(movieEndpoint).pipe(
        map(this.transformMoviePosterPath.bind(this))
      );
  }  
  searchTmdbMovie(query:string):Observable<Array<Movie>>{
     const movieEndpoint=`${this.tmdbSearchEndpoint}?${this.apiKey}&language=en-US&query=${query}`
      return this.http.get(movieEndpoint).pipe(
        map(this.pickMovieResults),
        map(this.transformPosterPath.bind(this))
      );
  } 
  getWatchListMovieById(movie_Id:number):Observable<Movie>{
     const movieEndpoint=`${this.watchListEndpoint}/${movie_Id}`
      return this.httpMovie.get(movieEndpoint).pipe(        
          map(this.mapMovie.bind(this))        
       );
  } 

   transformPosterPath(movies):Array<Movie>
   {
     return movies.map(movie=>{
      movie.poster_path=`${this.imgPath}${movie.poster_path}`;
      movie.comments="";
      movie.isWatchListedMovie=false;
      return movie;
     }); 
  }
  transformMoviePosterPath(movie):Movie
  {    
     movie.poster_path=`${this.imgPath}${movie.poster_path}`;
     movie.comments="";
     movie.isWatchListedMovie=false;
     return movie;
  }

   pickMovieResults(response)
    {
      return response["results"];
    }

    addMovieToWatchList(movie): Observable<any>
    {
      return this.httpMovie.post(this.watchListEndpoint,movie).pipe(
        map((res)=>{
              return res;
        }),
        catchError((err)=>{
          return throwError(err);
        }));
    }
   
    removeMoviefromWatchList(movie_Id:number): Observable<any>
    {
      return this.httpMovie.delete(this.watchListEndpoint+"/"+movie_Id).pipe(
        map((res)=>{
              return res;
        }),
        catchError((err)=>{
          return throwError(err);
        }));;
    }

    updateComments (updateMovie: IMovie) {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': 'my-auth-token'
        })
      };
      return this.httpMovie.put(this.watchListEndpoint+"/"+ updateMovie.id,JSON.stringify(updateMovie.comments))
        .pipe(
          catchError((err)=>{
            return throwError(err)})
        );
    }
    getWatchlistedMovies()
    {
       return this.httpMovie.get(this.watchListEndpoint).pipe(
        map((movies)=>{
              return this.mapMovies(movies);
        }),
        catchError((err)=>{
          return throwError(err);
        })
      );     
    }

    mapMovies(movies)
    {
      return movies.map((movie)=>{
        return this.mapMovie(movie);
      });
    }
    
    mapMovie(movie) {
      const tempMovie=new Movie();
      // let tempMovie = new Movie();
      tempMovie.id=movie.id;
      tempMovie.title=movie.title;
      tempMovie.overview=movie.overview;
      tempMovie.poster_path=movie.poster_path;
      tempMovie.release_date=movie.release_date;
      tempMovie.isWatchListedMovie=true;
      if(movie.comments==null || movie.comments==undefined )
      {
        tempMovie.comments="";
      }
      else{
      tempMovie.comments=movie.comments;
      }
      return tempMovie;
    }
  }
