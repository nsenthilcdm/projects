import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { AuthService } from './auth.service';
import {Observable} from 'rxjs';
import { Movie } from '../../movie';

@Injectable({
  providedIn: 'root'
})
export class MoviehttpclientService {

  constructor(private http:HttpClient,private authService:AuthService) { }

  createHeader(headers:HttpHeaders):HttpHeaders{
    headers=headers.set("Authorization","Bearer "+localStorage.getItem("jwt_token"))
    .set("Content-Type","application/json") 
    .set("Accept","application/json")   
    .set("userId",this.authService.getUserId()); 
    return headers;
  }

  get(url)
  {
    let headers=new HttpHeaders();
    headers=this.createHeader(headers);    
    return this.http.get(url,{headers:headers});
  }
  post(url,data)
  {
    let headers=new HttpHeaders();
    headers=this.createHeader(headers);  
    return this.http.post(url,data,{headers:headers});
  }
  put(url,data)
  {
    let headers=new HttpHeaders();
    headers=this.createHeader(headers);  
    return this.http.put(url,data,{headers:headers});
  }

  delete(url)
  {
    let headers=new HttpHeaders();
    headers=this.createHeader(headers);  
    return this.http.delete(url,{headers:headers});
  }
}
