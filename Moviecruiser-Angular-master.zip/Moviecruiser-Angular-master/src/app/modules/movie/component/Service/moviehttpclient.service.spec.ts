import { TestBed } from '@angular/core/testing';

import { MoviehttpclientService } from './moviehttpclient.service';

describe('MoviehttpclientService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MoviehttpclientService = TestBed.get(MoviehttpclientService);
    expect(service).toBeTruthy();
  });
});
