import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import 'rxjs/Rx';
import { JwtHelperService } from '@auth0/angular-jwt';
import { headersToString } from 'selenium-webdriver/http';
export const TOKEN_NAME: string ="jwt_token";
import { User } from '../../user';

@Injectable()
export class AuthService {

  constructor(private http:HttpClient) { }
  private headers=new HttpHeaders({'Content-Type':'application/json','Accept':'application/json'});
  private serviceUrl='http://localhost:49947/auth';
  userId:string="";

  getToken():string{
    return localStorage.getItem(TOKEN_NAME);
  }
    
  setToken(token:string): void{
      localStorage.setItem(TOKEN_NAME,token);
  }

  setUserId(userId:string){
    this.userId=userId;
  }

  getUserId(){
    return this.userId;
  }

  deleteToken():void{
    localStorage.removeItem(TOKEN_NAME);
  }

  getTokenExpirationDate(token:string):Date{
  const helper = new JwtHelperService();
  const date=helper.getTokenExpirationDate(token);
  return date
  }

  isTokenExpired(token?:string):boolean{
    const jwthelper = new JwtHelperService();
    if(!token)token=this.getToken();
    if(!token)return true;    
    return jwthelper.isTokenExpired(token);
  }

  login(user_Id:string,password:string){
    const url=this.serviceUrl+'/login';
    const json=JSON.stringify({userid:user_Id,password:password});
    this.setUserId(user_Id);   
    let options = {
      headers: this.headers
    }; 
    return this.http.post(url,json,options)
    .toPromise()
    .then(res=>res.toString())
    .catch((err)=>{return "unable to fetch token";});
  }
  
  RegisterUser(userDetail:User){
    const url=this.serviceUrl+'/register';
    const json=JSON.stringify(userDetail);
    let options = {
      headers: this.headers
    }; 
    return this.http.post(url,json,options)
    .toPromise()
    .then(res=>res.toString())
    .catch((err)=>{return err.status;});    
  }
  private handleError(error:any){
  console.error('an error occurred',error);
  }
}
