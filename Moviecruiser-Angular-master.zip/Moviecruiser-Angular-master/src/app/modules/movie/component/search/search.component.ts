import { Component, OnInit } from '@angular/core';
import {Movie} from '../../movie';
import {MovieService} from '../Service/movie.service';
import {ActivatedRoute, ParamMap} from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  movies: Array<Movie>;
  movieType:string;
  movieTitle:string;

  constructor(private movieService:MovieService, private route:ActivatedRoute) { 
    this.movies=[];
   } 

  ngOnInit() {
    this.route.paramMap.subscribe((params:ParamMap)=>{
    let title= params.get('title');
    this.movieTitle=title;
    this.movies=[];
    this.movieService.searchTmdbMovie(this.movieTitle).subscribe((movie)=>{           
      this.movies.push(...movie); 
    },(error)=>{
      window.alert("No results found");
    });
  });
  }
}
