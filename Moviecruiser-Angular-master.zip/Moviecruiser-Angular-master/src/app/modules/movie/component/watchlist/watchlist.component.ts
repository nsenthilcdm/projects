import { Component, OnInit } from '@angular/core';
import {Movie} from '../../movie';
import {MovieService} from '../Service/movie.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'movie-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchlistComponent implements OnInit {
  movies: Array<Movie>;
  constructor(private movieService:MovieService, private route:ActivatedRoute) {     
    this.movies=[];
   } 

  ngOnInit() {
    this.movieService.getWatchlistedMovies().subscribe((movies)=>
    {     
      this.movies.push(...movies); 
    },(err)=>{console.log(err)}); 
  } 

}
