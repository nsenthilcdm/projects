import { Authinterceptor } from './authinterceptor';

describe('Authinterceptor', () => {
  it('should create an instance', () => {
    expect(new Authinterceptor()).toBeTruthy();
  });
});
