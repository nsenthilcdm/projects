import { Injectable } from "@angular/core";
import {AuthService} from './../Service/auth.service';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpErrorResponse,
  HttpHeaders
} from "@angular/common/http";
import "rxjs/add/operator/do";
import { Observable } from "rxjs/Observable";

@Injectable()
export class Authinterceptor implements HttpInterceptor{
    constructor(private authsvc:AuthService) { }
  //function which will be called for all http calls
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
   
    const idToken=localStorage.getItem("jwt_token");
    if(idToken){
       const bearerToken="Bearer "+idToken;
        const cloned=request.clone({
            headers:request.headers.set("Authorization","Bearer "+idToken)
            .append("userId",this.authsvc.getUserId())           
        });
        
        return next.handle(cloned);
    } 
    else{
        return next.handle(request);        
    }   
  }
}
