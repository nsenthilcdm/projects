import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MovietoolbarComponent } from './movietoolbar.component';

describe('MovietoolbarComponent', () => {
  let component: MovietoolbarComponent;
  let fixture: ComponentFixture<MovietoolbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MovietoolbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovietoolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
