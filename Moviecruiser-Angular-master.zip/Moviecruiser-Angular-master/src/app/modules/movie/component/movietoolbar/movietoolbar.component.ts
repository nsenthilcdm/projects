import { Component, OnInit } from '@angular/core';
import {AuthService} from './../Service/auth.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-movietoolbar',
  templateUrl: './movietoolbar.component.html',
  styleUrls: ['./movietoolbar.component.css']
})
export class MovietoolbarComponent implements OnInit {
  public SearchString:string;
  constructor(private authsvc:AuthService,private router:Router) { }

  ngOnInit() {
  }
  logoutUser(){ 
    this.authsvc.deleteToken();
    this.router.navigate(['movies/login']);
  }
  searchMovie(){ 
    this.router.navigate(['/movies/search',this.SearchString]);
    }
}
