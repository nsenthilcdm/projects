import { Component, OnInit, Input } from '@angular/core';
import {Movie} from '../../movie';
import {MovieService} from '../Service/movie.service';
import {Route, Router} from '@angular/router';
import { IMovie } from '../../movie.interface';


@Component({
  selector: 'movie-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {
 @Input()
  movie: IMovie;  
   constructor(private movieService:MovieService, private router:Router) {    
    
   } 

  ngOnInit() {
    
  }
 
  selectDetails(movie)
  {
    this.router.navigate(['/movies',movie.id]);
  }
}
