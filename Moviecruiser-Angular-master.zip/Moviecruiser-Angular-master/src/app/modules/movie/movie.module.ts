import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import { ThumbnailComponent } from './component/thumbnail/thumbnail.component';
import {MovieService} from './component/Service/movie.service';
import { ContainerComponent } from './component/container/container.component';
import { MovieRouterModule } from './movie-router.module';
import { TmdbContainerComponent } from './component/tmdb-container/tmdb-container.component';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import { WatchlistComponent } from './component/watchlist/watchlist.component';
import {MatButtonModule} from '@angular/material/button';
import { MoviedetailComponent } from './component/moviedetail/moviedetail.component';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './component/login/login.component';
import {Authinterceptor} from './component/Interceptors/authinterceptor';
import {AuthService} from './component/Service/auth.service';
import {AuthGuardService} from './component/Service/auth-guard.service';
import { MovietoolbarComponent } from './component/movietoolbar/movietoolbar.component';
import {MoviehttpclientService} from './component/Service/moviehttpclient.service';
import { UserRegistrationComponent } from './component/user-registration/user-registration.component';
import { SearchComponent } from './component/search/search.component';
export const httpInterceptorProviders = [
  { provide: HTTP_INTERCEPTORS, useClass: Authinterceptor, multi: true },
];

@NgModule({
  imports: [
    MovieRouterModule,
    CommonModule,
    HttpClientModule,
    MatCardModule,
    MatButtonModule,     
    MatFormFieldModule, 
    FormsModule
  ],
  providers:[
    MovieService,AuthService,AuthGuardService,MoviehttpclientService
  ],
  declarations: [
    ThumbnailComponent,
    ContainerComponent,
    TmdbContainerComponent,
    WatchlistComponent,
    MoviedetailComponent,
    LoginComponent,
    MovietoolbarComponent,
    UserRegistrationComponent,
    SearchComponent,    
  ],
  exports:[
    ThumbnailComponent,
  ]
})
export class MovieModule { }
