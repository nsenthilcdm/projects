import {browser, by ,element} from 'protractor';
import { AppPage } from './app.po';
import { protractor } from 'protractor/built/ptor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
   //expect(page.getParagraphText()).toEqual('Welcome to ng-movie-cruiser-demo!');
   expect(browser.getTitle()).toEqual('NgMovieCruiserDemo');
  });
  it('should be redirected to login page on opening of application',()=> {
    expect(browser.getCurrentUrl()).toContain('/login');
  });
  it('should be redirected to register page on clicking register button',()=> {
    browser.element(by.id('register')).click()
    expect(browser.getCurrentUrl()).toContain('/user-registration');
  } );
  it('Should be able to register',()=> {
    browser.element(by.name('fname')).sendKeys('fname');
    browser.element(by.name('lname')).sendKeys('lname');
    browser.element(by.name('uid')).sendKeys('user2');
    browser.element(by.name('psw')).sendKeys('password2');    
    browser.element(by.className('registerbtn')).click();   
    //   let ale = browser.switchTo().alert();    
    //browser.waitForAngular();
    // expect(ale.getText()).toEqual("User Registered successfully"); 
    //ale.accept();
    expect(browser.getCurrentUrl()).toContain('/login');
  });
  it('Should be able to login',()=> {
    browser.element(by.name('userid')).sendKeys('user2');
    browser.element(by.name('password')).sendKeys('password2');    
    browser.element(by.id('login')).click(); 
    expect(browser.getCurrentUrl()).toContain('/popular');    
  } );

  it('Should be able to search movies',()=> {    
    browser.element(by.id('search')).sendKeys('super');
    browser.element(by.id('search')).sendKeys(protractor.Key.ENTER);    
    browser.waitForAngular();
    const searchItems=element.all(by.className('movieTitle')); 
    //expect(searchItems.count()).toBe(20);
    browser.waitForAngular();
    expect(browser.getCurrentUrl()).toContain('/search/super');   
    // for(let i=0;i<1;i=i+1){
    // expect(searchItems.get(i).getText()).toContain('super');
    // }    
  });
  it('Should be able to add movies to watch list',()=> {    
    browser.driver.manage().window().maximize();
    const searchItems=browser.element.all(by.className('movie-image')); 
    searchItems.get(0).click();    
    browser.element(by.id('comment')).sendKeys('nice movie');
    browser.element(by.id('addWatchList')).click();
    browser.waitForAngular();
    expect(browser.getCurrentUrl()).toContain('/watchlist');
    browser.driver.sleep(1000);
  });
  it('Should be able to logout',()=> {    
    browser.element(by.id('logout')).click();
    browser.waitForAngular();
    expect(browser.getCurrentUrl()).toContain('/login');  
    browser.driver.sleep(1000); 
  });
});
